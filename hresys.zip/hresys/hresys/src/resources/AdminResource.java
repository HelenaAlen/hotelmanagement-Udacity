package resources;

import model.Customer;
import model.IRoom;
import services.CustomerService;
import services.ReservationService;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class AdminResource {

    private static final AdminResource INSTANCE = new AdminResource();

    private final CustomerService clientManager;
    private final ReservationService bookingManager;

    private AdminResource() {
        clientManager = CustomerService.getSingleton();
        bookingManager = ReservationService.getSingleton();
    }

    public static AdminResource getSingleton() {
        return INSTANCE;
    }

    public Customer getCustomer(String email) {
        return Optional.ofNullable(email)
                .map(clientManager::getCustomer)
                .orElse(null);
    }

    public void addRoom(List<IRoom> rooms) {
        if (rooms != null) {
            rooms.forEach(this::addSingleRoom);
        }
    }

    private void addSingleRoom(IRoom room) {
        if (room != null) {
            bookingManager.addRoom(room);
        }
    }

    public Collection<IRoom> getAllRooms() {
        return bookingManager.getAllRooms();
    }

    public Collection<Customer> getAllCustomers() {
        return clientManager.getAllCustomers();
    }

    public void displayAllReservations() {
        bookingManager.printAllReservation();
    }
}