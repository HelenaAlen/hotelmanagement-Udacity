package services;

import java.util.*;
import model.Customer;
import model.IRoom;
import model.Reservation;

public class ReservationService {

    private static final ReservationService INSTANCE = new ReservationService();
    private static final int ALTERNATIVE_BOOKING_DAYS = 7;

    private final Map<Integer, IRoom> roomInventory = new TreeMap<>();
    private final Set<IRoom> roomSet = new HashSet<>();
    private final Map<String, List<Reservation>> bookingRegistry = new TreeMap<>();

    private ReservationService() {}

    public static ReservationService getSingleton() {
        return INSTANCE;
    }

    public void addRoom(final IRoom room) {
        if (roomSet.add(room)) {
            roomInventory.putIfAbsent(room.getRoomNumber(), room);
        } else {
            System.out.println("Room already exists in the inventory.");
        }
    }

    public IRoom getARoom(final String roomNumber) {
        return roomInventory.get(roomNumber);
    }

    public Collection<IRoom> getAllRooms() {
        return new ArrayList<>(roomInventory.values());
    }

    public Reservation reserveARoom(final Customer customer, final IRoom room,
                                    final Date checkInDate, final Date checkOutDate) {
        final Reservation newBooking = new Reservation(customer, room, checkInDate, checkOutDate);

        List<Reservation> customerBookings = bookingRegistry.computeIfAbsent(customer.getEmail(), k -> new ArrayList<>());
        customerBookings.add(newBooking);

        return newBooking;
    }

    public Collection<IRoom> findRooms(final Date checkInDate, final Date checkOutDate) {
        return getAvailableRooms(checkInDate, checkOutDate);
    }

    public Collection<IRoom> findAlternativeRooms(final Date checkInDate, final Date checkOutDate) {
        return getAvailableRooms(extendDate(checkInDate), extendDate(checkOutDate));
    }

    private Collection<IRoom> getAvailableRooms(final Date checkInDate, final Date checkOutDate) {
        Set<IRoom> occupiedRooms = new HashSet<>();

        for (Reservation booking : fetchAllReservations()) {
            if (isOverlapping(booking, checkInDate, checkOutDate)) {
                occupiedRooms.add(booking.getRoom());
            }
        }

        return roomInventory.values().stream()
                .filter(room -> !occupiedRooms.contains(room))
                .toList();
    }

    public Date extendDate(final Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, ALTERNATIVE_BOOKING_DAYS);
        return cal.getTime();
    }

    public Date addDefaultPlusDays(final Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, ALTERNATIVE_BOOKING_DAYS);

        return calendar.getTime();
    }

    private boolean isOverlapping(final Reservation booking, final Date checkInDate,
                                  final Date checkOutDate){
        return checkInDate.compareTo(booking.getCheckOutDate()) < 0
                && checkOutDate.compareTo(booking.getCheckInDate()) > 0;
    }

    public Collection<Reservation> getCustomersReservation(final Customer customer) {
        return bookingRegistry.getOrDefault(customer.getEmail(), Collections.emptyList());
    }

    public void printAllReservation() {
        Collection<Reservation> allBookings = fetchAllReservations();

        if (allBookings.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            allBookings.forEach(booking -> System.out.println(booking + "\n"));
        }
    }

    private Collection<Reservation> fetchAllReservations() {
        return bookingRegistry.values().stream()
                .flatMap(Collection::stream)
                .toList();
    }
}
