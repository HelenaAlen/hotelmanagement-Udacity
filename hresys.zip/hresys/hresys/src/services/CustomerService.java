package services;

import model.Customer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Optional;

public class CustomerService {

    private static final CustomerService SINGLETON = new CustomerService();

    private final ConcurrentHashMap<String, Customer> clientRegistry;

    private CustomerService() {
        clientRegistry = new ConcurrentHashMap<>();
    }

    public static CustomerService getSingleton() {
        return SINGLETON;
    }

    public void addCustomer(final String email, final String firstName, final String lastName) {
        clientRegistry.computeIfAbsent(email, k -> createCustomer(firstName, lastName, email));
    }

    public Customer getCustomer(final String customerEmail) {
        return Optional.ofNullable(clientRegistry.get(customerEmail)).orElse(null);
    }

    public Collection<Customer> getAllCustomers() {
        return new ArrayList<>(clientRegistry.values());
    }

    private Customer createCustomer(String firstName, String lastName, String email) {
        return new Customer(firstName, lastName, email);
    }
}