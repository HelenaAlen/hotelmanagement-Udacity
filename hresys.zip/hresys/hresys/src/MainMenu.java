import model.IRoom;
import model.Reservation;
import resources.HotelResource;

import java.util.Date;
import java.util.Scanner;
import java.util.Collection;
import java.util.function.Supplier;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class MainMenu {

    private static final Scanner scanner = new Scanner(System.in);
    private static final HotelResource hotelResource = HotelResource.getSingleton();
    private static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";

    public static void mainMenu() {
        String userChoice;
        do {
            printMainMenu();
            userChoice = scanner.nextLine().trim();
            menuoption(userChoice);
        } while (!"5".equals(userChoice));
    }

    private static void menuoption(String choice) {
        switch (choice) {
            case "1": roomreservation(); break;
            case "2": showreservations(); break;
            case "3": initiateAccountCreation(); break;
            case "4": AdminMenu.adminMenu(); break;
            case "5": System.out.println("Exit"); break;
            default: System.out.println("Error: Invalid action\n");
        }
    }

    private static void roomreservation() {
        Date checkIn = datein("Check-In");
        Date checkOut = datein("Check-Out");

        if (checkIn == null || checkOut == null) return;

        Collection<IRoom> availableRooms = hotelResource.findARoom(checkIn, checkOut);

        if (availableRooms.isEmpty()) {
            processAlternativeDates(checkIn, checkOut);
        } else {
            processRoomBooking(availableRooms, checkIn, checkOut);
        }
    }

    private static void showreservations() {
        String email = promptForInput("Enter your Email format: name@domain.com");
        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);

        if (reservations == null || reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            reservations.forEach(reservation -> System.out.println("\n" + reservation));
        }
    }

    private static void initiateAccountCreation() {
        String email = promptForInput("Enter Email format: name@domain.com");
        String firstName = promptForInput("First Name:");
        String lastName = promptForInput("Last Name:");

        try {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getLocalizedMessage());
            initiateAccountCreation();
        }
    }

    private static void processAlternativeDates(Date checkIn, Date checkOut) {
        Collection<IRoom> alternativeRooms = hotelResource.findAlternativeRooms(checkIn, checkOut);

        if (alternativeRooms.isEmpty()) {
            System.out.println("No rooms found for the given dates or alternative dates.");
        } else {
            Date altCheckIn = hotelResource.addDefaultPlusDays(checkIn);
            Date altCheckOut = hotelResource.addDefaultPlusDays(checkOut);
            System.out.println("We've only found rooms on alternative dates:" +
                    "\nCheck-In Date:" + altCheckIn +
                    "\nCheck-Out Date:" + altCheckOut);
            processRoomBooking(alternativeRooms, altCheckIn, altCheckOut);
        }
    }

    private static void processRoomBooking(Collection<IRoom> rooms, Date checkIn, Date checkOut) {
        rooms.forEach(System.out::println);

        if (getoption("Would you like to book? y/n")) {
            String email = validateUserEmail();
            if (email != null) {
                createReservation(email, rooms, checkIn, checkOut);
            }
        }
    }

    private static String validateUserEmail() {
        String email = promptForInput("Enter Email format: name@domain.com");

        if (hotelResource.getCustomer(email) == null) {
            System.out.println("Customer not found. You may need to create a new account.");
            return null;
        }
        return email;
    }

    private static void createReservation(String email, Collection<IRoom> rooms, Date checkIn, Date checkOut) {
         int roomNumber = -1;
        boolean validInput = false;

        while (!validInput) {
            try {
                String input = promptForInput("What room number would you like to reserve?");
                roomNumber = Integer.parseInt(input);
                validInput = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Room number must be a valid integer. Please try again.");
            }
        }

        IRoom selectedRoom = null;
        for (IRoom room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                selectedRoom = room;
                break;
            }
        }

        if (selectedRoom != null) {
            Reservation reservation = hotelResource.bookARoom(email, selectedRoom, checkIn, checkOut);
            System.out.println("Reservation created successfully!");
            System.out.println(reservation);
        } else {
            System.out.println("Error: room number not available. Start reservation again.");
        }
    }

    private static Date datein(String dateType) {
        Supplier<Date> dateSupplier = () -> {
            try {
                System.out.println("Enter " + dateType + " Date mm/dd/yyyy example 02/01/2020");
                return new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(scanner.nextLine());
            } catch (ParseException ex) {
                System.out.println("Error: Invalid date format. Please try again.");
                return null;
            }
        };

        Date date;
        do {
            date = dateSupplier.get();
        } while (date == null);

        return date;
    }

    private static boolean getoption(String prompt) {
        while (true) {
            System.out.println(prompt);
            String response = scanner.nextLine().toLowerCase().trim();
            if ("y".equals(response)) return true;
            if ("n".equals(response)) return false;
            System.out.println("Invalid input. Please enter 'y' or 'n'.");
        }
    }

    private static String promptForInput(String prompt) {
        System.out.println(prompt);
        return scanner.nextLine();
    }

    public static void printMainMenu()
    {
        System.out.print("\nWelcome to the Hotel Reservation Application\n" +
                "--------------------------------------------\n" + "1. Find and reserve a room\n" + "2. See my reservations\n" + "3. Create an Account\n" +
                "4. Admin\n" + "5. Exit\n" + "--------------------------------------------\n" + "Please select a number for the menu option:\n");
    }
}