import model.Room;
import model.RoomType;
import model.Customer;
import model.IRoom;
import resources.AdminResource;

import java.util.*;

public class AdminMenu {

    private static final AdminResource adminResource = AdminResource.getSingleton();
    private static final Scanner scanner = new Scanner(System.in);

    public static void adminMenu() {
        boolean continueAdminMenu = true;
        while (continueAdminMenu) {
            printMenu();
            String input = scanner.nextLine().trim();
            if (input.length() == 1) {
                continueAdminMenu = processMenuChoice(input.charAt(0));
            } else {
                System.out.println("Error: Invalid action\n");
            }
        }
    }

    private static void printMenu() {
        System.out.print("\nAdmin Menu\n" +
                "--------------------------------------------\n" + "1. See all Customers\n" + "2. See all Rooms\n" + "3. See all Reservations\n" +
                "4. Add a Room\n" + "5. Back to Main Menu\n" + "--------------------------------------------\n" + "Please select a number for the menu option:\n");
    }

    private static boolean processMenuChoice(char choice) {
        Map<Character, Runnable> menuActions = new HashMap<>();
        menuActions.put('1', AdminMenu::displayAllCustomers);
        menuActions.put('2', AdminMenu::displayAllRooms);
        menuActions.put('3', AdminMenu::displayAllReservations);
        menuActions.put('4', AdminMenu::addRoom);
        menuActions.put('5', MainMenu::printMainMenu);

        Runnable action = menuActions.getOrDefault(choice, () -> System.out.println("Unknown action\n"));
        action.run();
        return choice != '5';
    }

    private static void displayAllReservations() {
        adminResource.displayAllReservations();
    }

    private static void displayAllRooms() {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        displayCollection(rooms, "No rooms found.");
    }

    private static void displayAllCustomers() {
        Collection<Customer> customers = adminResource.getAllCustomers();
        displayCollection(customers, "No customers found.");
    }

    private static void addRoom() {
        int roomNumber = (int) getRoomId();

        double roomPrice = getRoomPrice();

        RoomType roomType = getRoomType();

        Room room = new Room(roomNumber, roomPrice, roomType);
        adminResource.addRoom(Collections.singletonList(room));
        System.out.println("Room added successfully!");

        promptAddAnotherRoom();
    }

    private static double getRoomId()
    {
        System.out.println("Enter room number:");
        while (true) {
            try {
                return Optional.of(scanner.nextLine())
                        .map(Double::parseDouble)
                        .orElseThrow(() -> new NumberFormatException("Invalid input"));
            } catch (NumberFormatException e) {
                System.out.println("Invalid room number. Room number should be a number\n");
            }
        }
    }

    private static double getRoomPrice() {
        System.out.println("Enter price per night:");
        while (true) {
            try {
                return Optional.of(scanner.nextLine())
                        .map(Double::parseDouble)
                        .orElseThrow(() -> new NumberFormatException("Invalid input"));
            } catch (NumberFormatException e) {
                System.out.println("Invalid room price! Please, enter a valid double number. Decimals should be separated by point (.)");
            }
        }
    }

    private static RoomType getRoomType() {
        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        Map<String, RoomType> roomTypeMap = new HashMap<>();
        roomTypeMap.put("1", RoomType.SINGLE);
        roomTypeMap.put("2", RoomType.DOUBLE);

        while (true) {
            String input = scanner.nextLine();
            if (roomTypeMap.containsKey(input)) {
                return roomTypeMap.get(input);
            }
            System.out.println("Invalid room type! Please, choose 1 for single bed or 2 for double bed:");
        }
    }

    private static void promptAddAnotherRoom() {
        System.out.println("Would you like to add another room? Y/N");
        while (true) {
            String input = scanner.nextLine().toUpperCase();
            if ("Y".equals(input)) {
                addRoom();
                break;
            } else if ("N".equals(input)) {
                break;
            } else {
                System.out.println("Please enter Y (Yes) or N (No)");
            }
        }
    }

    private static <T> void displayCollection(Collection<T> collection, String emptyMessage) {
        Optional.of(collection)
                .filter(c -> !c.isEmpty())
                .ifPresentOrElse(
                        c -> c.forEach(System.out::println),
                        () -> System.out.println(emptyMessage)
                );
    }
}