package model;

import java.util.Objects;
import java.util.regex.Pattern;

public class Customer {

    private static final String EMAIL_VALIDATION_ERROR = "Email address is not in a valid format. Please provide a correct email.";
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    private final String fName;
    private final String sname;
    private final String emailAddress;

    public Customer(String fName, String sname, String emailAddress) {
        this.fName = Objects.requireNonNull(fName, "Given name cannot be null");
        this.sname = Objects.requireNonNull(sname, "Surname cannot be null");
        this.emailAddress = verifyEmailFormat(emailAddress);
    }


    private String verifyEmailFormat(String email) {
        final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);
        final String EMAIL_VALIDATION_ERROR = "Invalid email format";
        if (email == null || email.trim().isEmpty() || !EMAIL_PATTERN.matcher(email).matches()) {
            throw new IllegalArgumentException(EMAIL_VALIDATION_ERROR);
        }
        return email;
    }

    public String getEmail() {
        return this.emailAddress;
    }

    @Override
    public String toString() {
        return String.format("Customer Details:%n" +
                        "  Given Name: %s%n" +
                        "  Surname: %s%n" +
                        "  Email Address: %s",
                this.fName, this.sname, this.emailAddress);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer)) return false;
        Customer other = (Customer) o;
        return Objects.equals(emailAddress, other.emailAddress);
    }

    @Override
    public int hashCode() {
        return Objects.hash(emailAddress);
    }
}