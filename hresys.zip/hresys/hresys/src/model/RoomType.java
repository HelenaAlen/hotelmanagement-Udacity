package model;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum RoomType {
    SINGLE("1"),
    DOUBLE("2");

    private static final Map<String, RoomType> LABEL_MAP = new HashMap<>();

    static {
        for (RoomType type : values()) {
            LABEL_MAP.put(type.label, type);
        }
    }

    public final String label;

    RoomType(String label) {
        this.label = label;
    }

    public static RoomType valueOfLabel(String label) {
        return Optional.ofNullable(LABEL_MAP.get(label))
                .orElseThrow(() -> new IllegalArgumentException("Invalid room type label: " + label));
    }
}