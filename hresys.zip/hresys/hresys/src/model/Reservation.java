package model;

import java.util.Date;
import java.util.Objects;
import java.text.SimpleDateFormat;

public class Reservation {

    private final Customer guest;
    private final IRoom accommodation;
    private final Date arrivalDate;
    private final Date departureDate;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    public Reservation(final Customer guest, final IRoom accommodation,
                       final Date arrivalDate, final Date departureDate) {
        this.guest = Objects.requireNonNull(guest, "Guest cannot be null");
        this.accommodation = Objects.requireNonNull(accommodation, "Room cannot be null");
        this.arrivalDate = new Date(arrivalDate.getTime());
        this.departureDate = new Date(departureDate.getTime());
    }

    public IRoom getRoom() {
        return this.accommodation;
    }

    public Date getCheckInDate() {
        return new Date(this.arrivalDate.getTime());
    }

    public Date getCheckOutDate() {
        return new Date(this.departureDate.getTime());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(this.guest).append("\n");
        sb.append("Room: ").append(this.accommodation).append("\n");
        sb.append("CheckIn Date: ").append(formatDate(this.arrivalDate)).append("\n");
        sb.append("CheckOut Date: ").append(formatDate(this.departureDate));
        return sb.toString();
    }

    private String formatDate(Date date) {
        return DATE_FORMAT.format(date);
    }
}