package model;

import java.util.Objects;

public class FreeRoom extends Room {

    private static final Double NO_CHARGE = 0.0;

    public FreeRoom(final int roomIdentifier, final RoomType classification) {
        super(Objects.requireNonNull(roomIdentifier, "Room identifier cannot be null"),
                NO_CHARGE,
                Objects.requireNonNull(classification, "Room classification cannot be null"));
    }

    @Override
    public String toString() {
        StringBuilder description = new StringBuilder("FreeRoom => ");
        description.append(super.toString());
        return description.toString();
    }

    @Override
    public boolean isFree() {
        return true;
    }

    @Override
    public Double getRoomPrice() {
        return NO_CHARGE;
    }
}