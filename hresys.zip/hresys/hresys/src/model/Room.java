package model;

import java.util.Objects;
import java.util.Optional;

public class Room implements IRoom {

    private final int roomId;
    private final Double rate;
    private final RoomType category;

    public Room(final int roomId, final Double rate, final RoomType category) {
        this.roomId = roomId;
        this.rate = rate;
        this.category = Objects.requireNonNull(category, "Room category cannot be null");
    }


    @Override
    public int getRoomNumber() {
        return this.roomId;
    }

    @Override
    public Double getRoomPrice() {
        return this.rate;
    }

    @Override
    public RoomType getRoomType() {
        return this.category;
    }

    @Override
    public boolean isFree() {
        return Optional.ofNullable(this.rate)
                .map(price -> price.compareTo(0.0) == 0)
                .orElse(false);
    }

    @Override
    public String toString() {
        return String.format("Room Number: %s Price: $%.2f Enumeration: %s", this.roomId, this.rate, this.category);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Room)) return false;
        Room other = (Room) obj;
        return Objects.equals(this.roomId, other.roomId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomId);
    }
}